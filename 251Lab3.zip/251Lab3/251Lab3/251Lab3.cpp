
// Caleb Jones, CIS 251 Lab #3

#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int main()
{
	// Problem 1

	int first, second, third;
	double avg;

	cout << "Enter the first, second, and third number here." << endl;

	cin >> first >> second >> third;

	cout << " " << first << " " << second << " " << third << endl;

	avg = (first + second + third) / static_cast<double>(3);

	cout << avg << endl;

	// Problem 2

	const double PI = 3.14159;
	float area, radius = 5.0;

	area = PI * pow(5, 2);

	cout << area << endl;

	// Problem 3

	int total = 0, a = 1, b = 2, c = 3, d = 4;

	total += d;
	total += a;
	total += c;
	total += b;

	cout << "Total =" << " " << total << endl;

	cout << "Average = " << setprecision(4) << fixed << avg << endl;
	cout << "Area = " << setprecision(4) << fixed << area << endl;

	system("pause");
	return 0;
}
